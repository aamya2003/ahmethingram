def say_hello(name):
    return f"Hello, {name}!"

def add(a, b):
    return a + b
